# Feature Specification: Estabilización del Repositorio y Fundación Package-by-Domain

**Feature Branch**: `014-repository-stabilization-domain-foundation`  
**Feature Directory**: `automation/specs/014-repository-stabilization-domain-foundation/`  
**Created**: 2026-07-11  
**Status**: Draft — pendiente autorización de ejecución  
**Input**: Estabilizar la arquitectura actual de VOXMETRIKS y consolidar package-by-domain sin cambiar el comportamiento funcional ni crear todavía los nuevos módulos empresariales.

**Prerrequisitos:** Constitución v1.0.0; specs 001–013; auditoría de dominio (sesión 2026-07-11, no versionada aún en `.specify/reviews/`).

**Número de spec:** **014** (siguiente disponible tras 013-academic-defense-deliverables).

---

## Contexto

VOXMETRIKS ya opera como monorepo (`apps/`, `analytics/`, `automation/`, `infrastructure/`). El package-by-domain parcial (`streaming`, `analytics`, `users`) coexiste con:

- Triple superficie API (`/api/v1` enterprise + packages + `/api/v2`)
- Dual ELT (`analytics/elt` + `apps/backend/app/etl`)
- Duplicación FE `features/` vs `packages/`
- Playback con dos capas (`MusicPlayerService` + `playback-core`)

Esta spec **no** introduce CRM, billing, organizations ni otros dominios empresariales vacíos. Solo estabiliza y consolida lo existente.

---

## Objetivo

> Estabilizar la arquitectura actual y consolidar package-by-domain **sin cambiar el comportamiento funcional** observable por usuarios finales, manteniendo adaptadores de compatibilidad hasta validar paridad.

---

## Fuera de alcance

- Crear dominios: organizations, crm, subscriptions, billing, campaigns, customer-success, support, compliance, catalog-rights
- Reescribir el reproductor
- Cambiar esquema DuckDB funcional sin migración explícita
- Mover `automation/specs` dentro de `.specify`
- Eliminar rutas legacy sin consumidores verificados
- Multi-tenant, Redis obligatorio, o escala “millones de usuarios”

---

## User Scenarios & Testing

### User Story 1 — Gobierno alineado con el monorepo real (Priority: P1)

Como mantenedor, necesito que la Constitución y Spec Kit describan la estructura real y las reglas de migración, para que ningún cambio futuro cree módulos vacíos ni rompa el gobierno OpenSpec.

**Why this priority**: Sin gobierno correcto, la consolidación de código contradice la autoridad del proyecto.

**Independent Test**: Leer Constitución actualizada y verificar que describe `apps/`, `automation/specs/`, package-by-domain técnico vs empresarial, audio real, y prohibición de módulos vacíos.

**Acceptance Scenarios**:

1. **Given** Constitución previa con desfaces (p. ej. audio WAV-only), **When** se aplica Fase B, **Then** refleja monorepo, specs en `automation/specs/`, audio YouTube/demo, y naming honesto AI/Enterprise/RC.
2. **Given** un intento de crear carpeta empresarial vacía, **When** se consulta la Constitución, **Then** está prohibido sin spec dedicada.

---

### User Story 2 — Frontend consolidado sin romper rutas (Priority: P1)

Como usuario de la SPA, sigo usando las mismas URLs (`/discover`, `/dashboard`, `/insights/*`, `/tracks`, etc.) tras absorber `features/` en `packages/`.

**Why this priority**: Regresión de navegación rompe demo y E2E.

**Independent Test**: `npm run build`, `npm run test`, `npm run lint`; rutas de `app.routes.ts` sin cambio de path; E2E disponibles.

**Acceptance Scenarios**:

1. **Given** rutas actuales en `app.routes.ts`, **When** se consolida `features/dashboard|analytics|tracks`, **Then** los paths públicos no cambian.
2. **Given** build/lint/unit verdes (o fallos documentados preexistentes), **When** termina Fase C, **Then** no hay regresión nueva atribuible a la consolidación.

---

### User Story 3 — Backend package-by-domain compatible (Priority: P1)

Como consumidor de `/api/v1`, las mismas operaciones siguen funcionando mientras el código canónico vive bajo `packages/{identity,catalog,engagement,analytics,ai}` con adaptadores para Enterprise V1 y V2.

**Why this priority**: El FE y demos dependen de contratos HTTP actuales.

**Independent Test**: pytest suites existentes; smoke de endpoints críticos; auth coherente en rutas sensibles.

**Acceptance Scenarios**:

1. **Given** FE usando `environment.apiUrl` → `/api/v1`, **When** se renombran/reubican packages, **Then** endpoints consumidos siguen respondiendo (adaptadores si hace falta).
2. **Given** rutas enterprise/v2 sensibles hoy sin auth, **When** Fase D aplica auth coherente, **Then** dejan de ser públicas sin romper flujos autenticados documentados.

---

### User Story 4 — ELT canónico único con adaptador de boot (Priority: P2)

Como operador, el pipeline canónico es `analytics/elt`; el backend no duplica lógica Medallion y puede invocar el pipeline vía adaptador sin romper el arranque actual hasta validar.

**Independent Test**: `make pipeline` / script ELT; boot API con flag de compatibilidad; tests `test_etl*` / `test_gold*` según disponibilidad.

**Acceptance Scenarios**:

1. **Given** dual ELT actual, **When** se declara canónico `analytics/elt`, **Then** la documentación y el adaptador de boot apuntan a esa fuente.
2. **Given** arranque con `RUN_ETL_ON_BOOT`, **When** no se ha validado el reemplazo, **Then** la compatibilidad de boot se mantiene.

---

### User Story 5 — Playback con una SoT y adaptador temporal (Priority: P2)

Como oyente, la reproducción no se degrada; `playback-core` es la fuente de verdad gradual y `MusicPlayerService` queda como adaptador hasta paridad + tests.

**Independent Test**: tests playback existentes; no eliminar `MusicPlayerService` en esta spec.

**Acceptance Scenarios**:

1. **Given** player en layout, **When** Fase F, **Then** no hay reescritura del motor; solo identificación SoT e integración gradual documentada.
2. **Given** cobertura insuficiente, **When** se evalúa tocar el player, **Then** se detiene ese cambio (regla de migración).

---

### Edge Cases

- Prueba no disponible en el entorno → documentar “no ejecutado”, no inventar PASS.
- Regresión no resoluble con evidencia → detener fase y revertir commit de etapa.
- Consumidor desconocido de ruta legacy → mantener adaptador; no archivar.

---

## Requirements

### Functional

- **FR-RS01**: Actualizar Constitución solo en secciones necesarias (monorepo, specs path, package-by-domain, audio, módulos vacíos, OpenSpec, naming, enfoque negocio→plataforma→datos→software).
- **FR-RS02**: Consolidar FE `features/` → `packages/` manteniendo paths de `app.routes.ts`.
- **FR-RS03**: Backend canónico bajo `packages/{identity,catalog,engagement,analytics,ai}` + `core/` + `platform/` + `api/` con shims/adaptadores.
- **FR-RS04**: Tratar `users` como identity mediante migración compatible (imports/re-exports temporales permitidos).
- **FR-RS05**: Definir API canónica packages `/api/v1`; Enterprise V1 y V2 como adaptadores mientras existan consumidores.
- **FR-RS06**: Auth coherente en rutas sensibles (cerrar huecos enterprise/v2/AI search públicos documentados).
- **FR-RS07**: `analytics/elt` = pipeline canónico; backend no duplica lógica Medallion.
- **FR-RS08**: Playback: SoT = playback-core; MusicPlayerService = adaptador; sin eliminación prematura.
- **FR-RS09**: Limpieza (imports legacy, docs, Docker, Makefile, CI, trazabilidad) solo tras evidencia de cero consumidores.
- **FR-RS10**: Commits pequeños por etapa; tests tras cada fase; no crear dominios empresariales vacíos.

### Non-Functional

- **NFR-RS01**: Sin cambio intencional de comportamiento UX/API para flujos demo (login, home, play, favoritos, playlists, explorer engineer).
- **NFR-RS02**: Specs permanecen en `automation/specs/`; `.specify` sigue siendo tooling/gobierno.

---

## Success Criteria

- **SC-RS01**: Spec 014 existe con `spec.md`, `plan.md`, `tasks.md`, `checklist.md`.
- **SC-RS02**: Tras ejecución autorizada, estructura FE/BE converge al layout canónico de esta spec (o gaps documentados con adaptadores).
- **SC-RS03**: Suites disponibles (pytest, vitest, build, lint) no introducen fallos nuevos; fallos preexistentes documentados.
- **SC-RS04**: Ningún dominio empresarial vacío creado.
- **SC-RS05**: Rutas FE públicas y contratos `/api/v1` consumidos por el SPA siguen operativos.

---

## Trazabilidad

| Artefacto | Relación |
|-----------|----------|
| Specs 001–013 | Base funcional; 014 no las mueve |
| Constitución | Enmienda puntual Fase B |
| Auditoría dominio 2026-07-11 | Input de diseño (no duplicar inventario aquí) |
| OMEGA / PRODUCTION_READINESS | Motivación de auth y dual-stack; fuera de alcance “escala internacional” |
