# Implementation Plan: Estabilización del Repositorio y Fundación Package-by-Domain

**Branch**: `014-repository-stabilization-domain-foundation` | **Date**: 2026-07-11 | **Spec**: [spec.md](./spec.md)

**Status**: Draft — no ejecutar hasta autorización

## Summary

Consolidar package-by-domain técnico (`identity`, `catalog`, `engagement`, `analytics`, `ai`) sobre el monorepo existente, con adaptadores de compatibilidad para API triple, dual ELT y playback dual-stack, **sin** nuevos módulos empresariales y **sin** cambio funcional intencional.

## Technical Context

**Language/Version**: Python 3.12 (backend), TypeScript / Angular 21 (frontend)

**Primary Dependencies**: FastAPI, DuckDB, Angular, Spec Kit (`.specify` + `automation/specs`)

**Storage**: DuckDB `data/warehouse/` (sin cambio de esquema en esta spec salvo migración explícita futura)

**Testing**: pytest (`apps/backend`), Vitest + build + lint (`apps/frontend`), Playwright (`automation/playwright`) según disponibilidad

**Target Platform**: Dev local Windows + Docker compose (`workers: 1`)

**Project Type**: Monorepo web (apps + analytics + automation + infrastructure)

**Constraints**:
- No romper rutas FE ni contratos `/api/v1` consumidos
- No mover specs 001–013
- No crear carpetas empresariales vacías
- Commits pequeños; stop on unresolvable regression
- Player: no rewrite; cobertura insuficiente ⇒ no tocar

**Scale/Scope**: Estabilización estructural; no escala multi-tenant

## Constitution Check

| Gate | Expectativa |
|------|-------------|
| §13 Organización monorepo | Mantener raíz; enmienda solo desfaces |
| Package-by-domain | Consolidar packages técnicos; no dominios vacíos |
| §16 Implementación | Sin cambio de comportamiento intencional |
| Specs en `automation/specs/` | Conservar ubicación |
| OpenSpec / Spec Kit | Spec 014 antes de ejecución de fases C–G |

## Phased Execution (autorizada por el usuario)

| Fase | Nombre | Entregable clave | Stop condition |
|------|--------|------------------|----------------|
| **A** | Baseline | Rama + commit baseline + resumen tests | Proyecto ya roto sin causa de 014 |
| **B** | Constitución | Enmienda puntual `.specify/memory/constitution.md` | — |
| **C** | Frontend | `features/` → `packages/`; rutas iguales | Fallo build/lint/unit/e2e nuevo |
| **D** | Backend | packages canónicos + API adaptadores + auth sensible | Regresión API / pytest |
| **E** | ELT | `analytics/elt` canónico + adaptador boot | Boot/demo warehouse roto |
| **F** | Playback | SoT documentada + integración gradual | Sin cobertura ⇒ skip cambios player |
| **G** | Limpieza | Legacy sin consumidores; docs/CI/Docker/Makefile/trazabilidad | Consumidor residual encontrado |

## Target Layout (post-014, gradual)

### Backend

```text
apps/backend/app/
├── core/
├── platform/
├── packages/
│   ├── identity/      # desde users (+ shims)
│   ├── catalog/       # catálogo desde streaming
│   ├── engagement/    # playlists, favorites, history APIs, playback bridge
│   ├── analytics/     # existente + smart
│   └── ai/            # existente
└── api/               # canónico + adaptadores enterprise/v2
```

### Frontend

```text
apps/frontend/src/app/
├── core/
├── shell/             # layouts (dashboard/auth) si se renombra layouts/
├── packages/
│   ├── identity/
│   ├── catalog/
│   ├── engagement/
│   ├── analytics/
│   ├── data-engineering/
│   ├── administration/
│   ├── smart/
│   └── ai/
└── shared/
```

`playback-core/` puede permanecer en la raíz de `src/app` o vivir bajo `engagement` vía re-export; **no eliminar** `MusicPlayerService` en 014.

## Compatibility Strategy

| Superficie | Estrategia |
|------------|------------|
| FE routes | Paths inmutables; solo cambian `loadComponent` imports |
| Packages BE rename | `users` → `identity` con re-exports temporales en ruta antigua |
| Enterprise V1 / V2 | Thin adapters → servicios canónicos; auth añadida en D |
| Dual ELT | Canónico `analytics/elt`; `app/etl` → invocación/adaptador hasta validar |
| Playback | SoT `playback-core`; `MusicPlayerService` facade |

## Project Structure (this feature)

```text
automation/specs/014-repository-stabilization-domain-foundation/
├── spec.md
├── plan.md
├── tasks.md
└── checklist.md
```

No se generan `research.md` / `data-model.md` / `contracts/` en el draft: la auditoría de dominio ya cubre el inventario; evitar duplicación.

## Validation per Phase

Ejecutar lo disponible; registrar solo resumen:

- `apps/backend`: `python -m pytest …`
- `apps/frontend`: `npm run test`, `npm run build`, `npm run lint`
- Playwright: `npm run e2e` (root) si entorno listo
- ELT: `make pipeline` / scripts validate_warehouse si aplica
- Arranque: uvicorn + navegación básica

No inventar resultados.

## Risks (referenciados, no re-auditados)

Auth enterprise/v2; acoplamiento smart↔recommendation_engine↔ai; dual ELT; player sin cobertura plena — ver auditoría 2026-07-11 y `docs/VOXMETRIKS_OMEGA_REVIEW.md`.

## Next Step After Approval

1. Actualizar `.specify/feature.json` → este directorio  
2. Crear rama `014-repository-stabilization-domain-foundation`  
3. Ejecutar Fase A → … según [tasks.md](./tasks.md)
