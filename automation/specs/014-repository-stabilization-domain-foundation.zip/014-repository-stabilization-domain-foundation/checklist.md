# Requirements Checklist: Spec 014 — Repository Stabilization Domain Foundation

**Purpose**: Gate de aceptación antes/durante/después de la ejecución autorizada  
**Created**: 2026-07-11  
**Feature**: [spec.md](./spec.md) · [plan.md](./plan.md) · [tasks.md](./tasks.md)

## Gobierno

- [ ] CHK001 Spec número **014** confirmado (siguiente tras 013)
- [ ] CHK002 Carpeta `automation/specs/014-repository-stabilization-domain-foundation/` contiene solo spec/plan/tasks/checklist (draft)
- [ ] CHK003 Specs 001–013 no movidas
- [ ] CHK004 `.specify` permanece como tooling/gobierno; specs siguen en `automation/specs/`
- [ ] CHK005 Ningún dominio empresarial vacío creado (crm, billing, orgs, etc.)

## Constitución (Fase B)

- [ ] CHK006 Monorepo real documentado (`apps/`, `analytics/`, `automation/`, `infrastructure/`)
- [ ] CHK007 Ubicación real de specs documentada
- [ ] CHK008 Package-by-domain técnico vs empresarial aclarado
- [ ] CHK009 Estado real de audio documentado
- [ ] CHK010 Prohibición de módulos vacíos + OpenSpec antes de cambios estructurales
- [ ] CHK011 Naming honesto AI / Enterprise / RC
- [ ] CHK012 Enfoque negocio → plataforma → datos → software presente

## Frontend (Fase C)

- [ ] CHK013 Paths de `app.routes.ts` sin cambio de URL pública
- [ ] CHK014 `features/` absorbido o plan de residual documentado
- [ ] CHK015 lint / unit / build ejecutados; resultados reales registrados
- [ ] CHK016 Playwright ejecutado o marcado no disponible
- [ ] CHK017 Player no reescrito; MusicPlayerService no eliminado

## Backend (Fase D)

- [ ] CHK018 Packages canónicos identity/catalog/engagement/analytics/ai (o shims equivalentes)
- [ ] CHK019 API canónica definida; enterprise V1 y V2 como adaptadores mientras haya consumidores
- [ ] CHK020 Auth coherente en rutas sensibles previamente públicas
- [ ] CHK021 Contratos `/api/v1` usados por FE operativos
- [ ] CHK022 pytest ejecutado; sin regresiones nuevas no documentadas

## ELT (Fase E)

- [ ] CHK023 `analytics/elt` declarado canónico
- [ ] CHK024 Backend sin lógica Medallion duplicada activa (adaptador OK)
- [ ] CHK025 Compatibilidad de boot preservada hasta validación
- [ ] CHK026 Validación ELT/warehouse ejecutada o no disponible documentada

## Playback (Fase F)

- [ ] CHK027 SoT = playback-core documentada
- [ ] CHK028 MusicPlayerService permanece como adaptador hasta paridad+tests
- [ ] CHK029 Si falta cobertura, cambios de player omitidos con evidencia

## Limpieza (Fase G)

- [ ] CHK030 Shims/legacy retirados solo con grep de cero consumidores
- [ ] CHK031 README / QUICKSTART / Docker / Makefile / CI actualizados si aplicó
- [ ] CHK032 Trazabilidad actualizada o deuda explícita
- [ ] CHK033 Validación final registrada sin resultados inventados

## Stop conditions

- [ ] CHK034 Si regresión no resoluble → fase detenida y revertida
- [ ] CHK035 Commits pequeños por etapa realizados (cuando se autorice ejecución)

## Notes

- Marcar `[x]` solo con evidencia.
- Este checklist no sustituye la auditoría de dominio; la referencia.
