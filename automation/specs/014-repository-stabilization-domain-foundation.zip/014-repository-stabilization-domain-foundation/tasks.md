# Tasks: Estabilización del Repositorio y Fundación Package-by-Domain

**Input**: [spec.md](./spec.md), [plan.md](./plan.md)  
**Prerequisites**: Autorización explícita del usuario para ejecutar (draft actual)  
**Status**: Pending approval

## Format: `[ID] [P?] [Story] Description`

---

## Phase A: Baseline y respaldo

**Purpose**: Rama limpia + evidencia de salud previa

- [ ] T001 Create git branch `014-repository-stabilization-domain-foundation` from current HEAD
- [ ] T002 Commit or stash only intentional WIP; record clean baseline commit message for 014 start
- [ ] T003 Run available backend pytest (summary only); abort 014 if suite already broken unrelated to 014
- [ ] T004 [P] Run available frontend `npm run test` / `build` / `lint` (summary only)
- [ ] T005 Document baseline results in commit message or short note under this spec folder only if needed (no new audit doc)

**Checkpoint A**: Baseline green or failures pre-documented → continue

---

## Phase B: Constitución y gobierno (US1)

**Purpose**: Enmienda puntual — no reescritura total

- [ ] T006 [US1] Patch `.specify/memory/constitution.md`: monorepo `apps/` + `analytics/` + `automation/` + `infrastructure/`
- [ ] T007 [US1] Patch constitution: specs live in `automation/specs/` (not inside `.specify`)
- [ ] T008 [US1] Patch constitution: package-by-domain técnico vs dominios empresariales futuros; ban empty modules
- [ ] T009 [US1] Patch constitution: real audio state (YouTube/Audius/demo — not WAV-only)
- [ ] T010 [US1] Patch constitution: OpenSpec/Spec Kit required before relevant structural changes; honest naming AI/Enterprise/RC
- [ ] T011 [US1] Patch constitution: approach negocio → plataforma → datos → software (short clause)
- [ ] T012 [US1] Set `.specify/feature.json` → `automation/specs/014-repository-stabilization-domain-foundation`
- [ ] T013 Commit: `docs(constitution): align monorepo and package-by-domain rules for spec 014`

**Checkpoint B**: Constitution diff reviewed

---

## Phase C: Frontend consolidation (US2)

**Purpose**: Absorb `features/` into `packages/`; keep route paths

- [ ] T014 [US2] Map `features/dashboard` → target under `packages/` (analytics or shell dashboard); update `app.routes.ts` imports only
- [ ] T015 [US2] Map `features/analytics` → `packages/analytics`; dedupe with existing analytics component
- [ ] T016 [US2] Map `features/tracks` (insights) → `packages/` without colliding CRUD `/tracks`
- [ ] T017 [US2] Introduce `packages/identity|catalog|engagement` folders only when moving real code (no empty dirs)
- [ ] T018 [US2] Optionally rename `layouts/` → `shell/` with re-exports if low-risk; else defer
- [ ] T019 [US2] Remove obsolete `features/` files after zero imports
- [ ] T020 [US2] Run `npm run lint`, `npm run test`, `npm run build`
- [ ] T021 [US2] Run Playwright if available; else document skip
- [ ] T022 Commit: `refactor(frontend): consolidate features into packages (spec 014)`

**Checkpoint C**: Routes unchanged; FE gates pass or documented

**Do not**: rewrite player / delete MusicPlayerService

---

## Phase D: Backend consolidation (US3)

**Purpose**: Canonical packages + adapters + auth on sensitive routes

- [ ] T023 [US3] Add compatibility shims: `packages/users` re-exports → `packages/identity` (or rename with shim path)
- [ ] T024 [US3] Split or alias `packages/streaming` into `catalog` + `engagement` with temporary re-exports preserving import paths
- [ ] T025 [US3] Keep `packages/analytics` and `packages/ai`; ensure `main.py` still mounts working routers
- [ ] T026 [US3] Define canonical router registration in `app/api/`; wrap enterprise V1 + V2 as adapters
- [ ] T027 [US3] Apply coherent auth to sensitive enterprise/v2/AI routes (close public gaps) without breaking authenticated FE flows
- [ ] T028 [US3] Update imports across backend; keep temporary `from app.packages.users…` shims
- [ ] T029 [US3] Run pytest (auth, analytics_security, smart, ai, platform, api_v2, enterprise as available)
- [ ] T030 Commit: `refactor(backend): package-by-domain foundation with API adapters (spec 014)`

**Checkpoint D**: `/api/v1` FE contracts OK; pytest summary recorded

---

## Phase E: ELT canonical (US4)

- [ ] T031 [US4] Document and wire `analytics/elt` as canonical pipeline in Makefile/docs used by ops
- [ ] T032 [US4] Replace or wrap duplicate Medallion logic in `apps/backend/app/etl` with adapter invoking canonical pipeline
- [ ] T033 [US4] Preserve `RUN_ETL_ON_BOOT` compatibility until replacement validated
- [ ] T034 [US4] Run ELT/warehouse validation scripts if available; else document skip
- [ ] T035 Commit: `refactor(elt): canonical analytics/elt with backend adapter (spec 014)`

**Checkpoint E**: Boot + pipeline still produce usable warehouse for demo

---

## Phase F: Playback SoT (US5)

- [ ] T036 [US5] Document single source of truth = `playback-core` in short note (constitution pointer or phase comment in plan progress)
- [ ] T037 [US5] Gradual integration only where tests exist; keep `MusicPlayerService` as adapter
- [ ] T038 [US5] If coverage insufficient, mark T037 skipped with evidence — do not delete MusicPlayerService
- [ ] T039 [US5] Run existing playback-related vitest specs
- [ ] T040 Commit only if code changed: `refactor(playback): affirm playback-core SoT via adapter (spec 014)`

**Checkpoint F**: Playback demo path intact

---

## Phase G: Cleanup

- [ ] T041 Remove legacy imports/shims only after grep shows zero consumers
- [ ] T042 Archive unused route modules if any; do not delete with uncertainty
- [ ] T043 Update `README.md`, `docs/QUICKSTART.md`, Docker, root/`infrastructure` Makefile, `.github/workflows/ci.yml` paths if needed
- [ ] T044 Update TRACEABILITY evidence paths for renamed packages (tooling or manual appendix)
- [ ] T045 Final validation suite (pytest + FE check + e2e if available)
- [ ] T046 Commit: `chore: post-014 cleanup and docs alignment`

**Checkpoint G**: Spec 014 complete or remaining gaps listed in checklist

---

## Dependencies

- A → B → C and D may proceed after B; prefer **C before D** if FE must keep calling stable URLs while BE shims land
- E after D (orchestrator/imports stable)
- F independent after A but avoid parallel with risky C player touches (player frozen)
- G last

## Parallel opportunities

- T004 ∥ T003  
- Within C: mapping tasks sequential by route collision risk  
- D shims before auth tightening
